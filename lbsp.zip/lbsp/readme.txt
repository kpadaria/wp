=== Plugin Name ===
Plugin Name:Library Book Search Plugin 
Plugin URI: #
Tags: Book ,Search book
Requires at least: 3.5
License: GPL


== Description ==

Awesome plugin for search books for library system
<h4>Features</h4>
* Fully responsive
* search by book name, price, author, publisher etc..
* Use search code [search_book] for display search form



